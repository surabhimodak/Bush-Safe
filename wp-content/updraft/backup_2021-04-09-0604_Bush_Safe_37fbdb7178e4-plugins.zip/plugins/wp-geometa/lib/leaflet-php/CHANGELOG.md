Changelog
========

0.0.2
-----
* Upgraded Leaflet to version 1.2.0
* Forked version of Leaflet.draw with GPSLine support

0.0.1
-----
* Proof of concept
* Leaflet.draw
* Leaflet geolocate
